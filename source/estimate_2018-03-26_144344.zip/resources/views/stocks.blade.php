{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('size_id', 'Size_id:') !!}
			{!! Form::text('size_id') !!}
		</li>
		<li>
			{!! Form::label('weight', 'Weight:') !!}
			{!! Form::text('weight') !!}
		</li>
		<li>
			{!! Form::label('cost_per_k', 'Cost_per_k:') !!}
			{!! Form::text('cost_per_k') !!}
		</li>
		<li>
			{!! Form::label('supplier_id', 'Supplier_id:') !!}
			{!! Form::text('supplier_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}