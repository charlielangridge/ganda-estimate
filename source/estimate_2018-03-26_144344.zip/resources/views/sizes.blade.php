{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('dim_x', 'Dim_x:') !!}
			{!! Form::text('dim_x') !!}
		</li>
		<li>
			{!! Form::label('dim_y', 'Dim_y:') !!}
			{!! Form::text('dim_y') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}