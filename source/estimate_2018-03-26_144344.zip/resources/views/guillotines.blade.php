{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('max_width', 'Max_width:') !!}
			{!! Form::text('max_width') !!}
		</li>
		<li>
			{!! Form::label('max_depth', 'Max_depth:') !!}
			{!! Form::text('max_depth') !!}
		</li>
		<li>
			{!! Form::label('min_depth', 'Min_depth:') !!}
			{!! Form::text('min_depth') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}