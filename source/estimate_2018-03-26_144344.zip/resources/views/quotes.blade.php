{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('user_id', 'User_id:') !!}
			{!! Form::text('user_id') !!}
		</li>
		<li>
			{!! Form::label('qty1', 'Qty1:') !!}
			{!! Form::text('qty1') !!}
		</li>
		<li>
			{!! Form::label('qty2', 'Qty2:') !!}
			{!! Form::text('qty2') !!}
		</li>
		<li>
			{!! Form::label('qty3', 'Qty3:') !!}
			{!! Form::text('qty3') !!}
		</li>
		<li>
			{!! Form::label('q1_waste', 'Q1_waste:') !!}
			{!! Form::text('q1_waste') !!}
		</li>
		<li>
			{!! Form::label('q2_waste', 'Q2_waste:') !!}
			{!! Form::text('q2_waste') !!}
		</li>
		<li>
			{!! Form::label('q3_waste', 'Q3_waste:') !!}
			{!! Form::text('q3_waste') !!}
		</li>
		<li>
			{!! Form::label('originals', 'Originals:') !!}
			{!! Form::text('originals') !!}
		</li>
		<li>
			{!! Form::label('setup_mins', 'Setup_mins:') !!}
			{!! Form::text('setup_mins') !!}
		</li>
		<li>
			{!! Form::label('job_type_id', 'Job_type_id:') !!}
			{!! Form::text('job_type_id') !!}
		</li>
		<li>
			{!! Form::label('press_id', 'Press_id:') !!}
			{!! Form::text('press_id') !!}
		</li>
		<li>
			{!! Form::label('colour', 'Colour:') !!}
			{!! Form::text('colour') !!}
		</li>
		<li>
			{!! Form::label('stock_id', 'Stock_id:') !!}
			{!! Form::text('stock_id') !!}
		</li>
		<li>
			{!! Form::label('imposition_id', 'Imposition_id:') !!}
			{!! Form::text('imposition_id') !!}
		</li>
		<li>
			{!! Form::label('guillotine_id', 'Guillotine_id:') !!}
			{!! Form::text('guillotine_id') !!}
		</li>
		<li>
			{!! Form::label('packaging_id', 'Packaging_id:') !!}
			{!! Form::text('packaging_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}