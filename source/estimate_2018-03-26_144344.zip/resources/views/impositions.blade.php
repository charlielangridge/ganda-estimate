{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('press_id', 'Press_id:') !!}
			{!! Form::text('press_id') !!}
		</li>
		<li>
			{!! Form::label('impose_type_id', 'Impose_type_id:') !!}
			{!! Form::text('impose_type_id') !!}
		</li>
		<li>
			{!! Form::label('finished_size_id', 'Finished_size_id:') !!}
			{!! Form::text('finished_size_id') !!}
		</li>
		<li>
			{!! Form::label('sheet_size_id', 'Sheet_size_id:') !!}
			{!! Form::text('sheet_size_id') !!}
		</li>
		<li>
			{!! Form::label('duplex', 'Duplex:') !!}
			{!! Form::text('duplex') !!}
		</li>
		<li>
			{!! Form::label('orientation', 'Orientation:') !!}
			{!! Form::text('orientation') !!}
		</li>
		<li>
			{!! Form::label('rows', 'Rows:') !!}
			{!! Form::text('rows') !!}
		</li>
		<li>
			{!! Form::label('columns', 'Columns:') !!}
			{!! Form::text('columns') !!}
		</li>
		<li>
			{!! Form::label('bleed_x', 'Bleed_x:') !!}
			{!! Form::text('bleed_x') !!}
		</li>
		<li>
			{!! Form::label('bleed_y', 'Bleed_y:') !!}
			{!! Form::text('bleed_y') !!}
		</li>
		<li>
			{!! Form::label('gutter', 'Gutter:') !!}
			{!! Form::text('gutter') !!}
		</li>
		<li>
			{!! Form::label('marks', 'Marks:') !!}
			{!! Form::text('marks') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}