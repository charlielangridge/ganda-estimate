{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('print_method_id', 'Print_method_id:') !!}
			{!! Form::text('print_method_id') !!}
		</li>
		<li>
			{!! Form::label('click_black', 'Click_black:') !!}
			{!! Form::text('click_black') !!}
		</li>
		<li>
			{!! Form::label('click_colour', 'Click_colour:') !!}
			{!! Form::text('click_colour') !!}
		</li>
		<li>
			{!! Form::label('weight_min', 'Weight_min:') !!}
			{!! Form::text('weight_min') !!}
		</li>
		<li>
			{!! Form::label('weight_max', 'Weight_max:') !!}
			{!! Form::text('weight_max') !!}
		</li>
		<li>
			{!! Form::label('grip_top', 'Grip_top:') !!}
			{!! Form::text('grip_top') !!}
		</li>
		<li>
			{!! Form::label('grip_bottom', 'Grip_bottom:') !!}
			{!! Form::text('grip_bottom') !!}
		</li>
		<li>
			{!! Form::label('size_min_id', 'Size_min_id:') !!}
			{!! Form::text('size_min_id') !!}
		</li>
		<li>
			{!! Form::label('size_max_id', 'Size_max_id:') !!}
			{!! Form::text('size_max_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}